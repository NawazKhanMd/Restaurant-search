module.exports = {
  verbose: true,
};