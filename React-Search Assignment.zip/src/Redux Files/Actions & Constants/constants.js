export const home_action_types = {
    get_cities_success: 'get_cities_success',
    get_cities_fail: 'get_cities_success',
    get_restaurants_success: 'get_restaurants_success',
    get_restaurants_fail: 'get_restaurants_fail',
    filter_restaurants:'filter_restaurants',
    loading:'loading'
} 