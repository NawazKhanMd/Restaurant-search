let gradient = [
];

let sliderWidth = 200;

export const getColorFromGradient = (value) => {
   
            return false;
  
};

const pickHex = (color1, color2, weight) =>{
   
    return null;
}

export const MapStyles = [
  ]
